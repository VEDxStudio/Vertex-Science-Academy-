/** Tailwind-compatible source configuration for future UI rebuilds. The shipped PWA is dependency-free/offline-first. */
module.exports = {
  content: ['./index.html', './app.js'],
  theme: { extend: { colors: { vertex: { navy:'#0F172A', blue:'#1E3A8A', orange:'#F97316', saffron:'#EA580C', slate50:'#F8FAFC' } } } },
  plugins: []
};
