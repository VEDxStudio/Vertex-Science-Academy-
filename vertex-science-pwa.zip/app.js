const OWNER_KEY_SHA256 = 'f66b706b51d1147b1b041a934cb33ca751ef47940ad8e363c8858a31a96f38b0';
const CHAPTERS = [
  ['Physics',['Light - Reflection & Refraction','The Human Eye','Electricity','Magnetic Effects of Electric Current']],
  ['Chemistry',['Chemical Reactions & Equations','Acids Bases & Salts','Metals & Non-metals','Carbon and its Compounds']],
  ['Biology',['Life Processes','Control & Coordination','How do Organisms Reproduce?','Heredity']]
];
const ICONS = {
  home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1Z"/>',
  book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/>',
  chart:'<path d="M3 3v18h18"/><path d="m7 16 4-5 3 3 6-8"/>',
  calendar:'<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  eye:'<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/>',
  eyeOff:'<path d="m3 3 18 18"/><path d="M10.6 5.1A10.7 10.7 0 0 1 12 5c6.5 0 10 7 10 7a18.5 18.5 0 0 1-3.1 3.7M6.2 6.2C3.6 8 2 12 2 12s3.5 7 10 7a9.7 9.7 0 0 0 4.2-.9"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  logout:'<path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M21 19V5a2 2 0 0 0-2-2h-6"/>',
  lock:'<rect width="16" height="12" x="4" y="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  print:'<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/>',
  download:'<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>',
  upload:'<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M5 20h14"/>',
  moon:'<path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.5 8.5 0 1 0 20.5 15.5Z"/>',
  chevron:'<path d="m9 18 6-6-6-6"/>',
  target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>'
};
const icon = (name,size=18) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]||''}</svg>`;
const $ = id => document.getElementById(id);
const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
let state = { page:'home', subject:'Physics', dark:localStorage.getItem('vertex_dark')==='1', report:false, error:'', showPass:false, enrollment:false };

function seed(){
  if(!localStorage.getItem('vertex_chapters')){
    const items=[]; CHAPTERS.forEach(([subject,names])=>names.forEach((chapter,i)=>items.push({id:`${subject}-${i}`,subject,chapter,status:'Not Started'}))); write('vertex_chapters',items);
  }
  if(!localStorage.getItem('vertex_slots')) write('vertex_slots',[
    {id:1,date:'2026-10-05',time:'08:00 AM',batch:'Morning A',seat:'',status:'Open'},
    {id:2,date:'2026-10-05',time:'02:00 PM',batch:'Afternoon B',seat:'',status:'Open'},
    {id:3,date:'2026-10-12',time:'08:00 AM',batch:'Morning A',seat:'',status:'Open'},
    {id:4,date:'2026-10-12',time:'02:00 PM',batch:'Afternoon B',seat:'',status:'Open'},
    {id:5,date:'2026-10-19',time:'08:00 AM',batch:'Morning A',seat:'',status:'Open'},
    {id:6,date:'2026-10-19',time:'02:00 PM',batch:'Afternoon B',seat:'',status:'Open'}
  ]);
  if(!localStorage.getItem('vertex_tests')) write('vertex_tests',[]);
  if(!localStorage.getItem('vertex_activities')) write('vertex_activities',[]);
}
async function sha256(text){const data=new TextEncoder().encode(text);const hash=await crypto.subtle.digest('SHA-256',data);return [...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,'0')).join('');}
function profile(){return read('vertex_profile',null)}
function loggedIn(){return !!profile()?.loggedIn}
function setProfile(p){write('vertex_profile',p)}
function logActivity(type,title,durationMinutes=0){const a=read('vertex_activities',[]);a.unshift({id:Date.now(),type,title,dateTime:new Date().toISOString(),durationMinutes});write('vertex_activities',a.slice(0,50));}
function firstName(name){return (name||'Student').trim().split(/\s+/)[0]||'Student'}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function statusClass(s){return s==='Mastered'?'m':s==='In Progress'?'ip':s==='Revision Due'?'rd':'ns'}
function nextStatus(s){return s==='Not Started'?'In Progress':s==='In Progress'?'Mastered':s==='Mastered'?'Revision Due':'Not Started'}
function chapters(){return read('vertex_chapters',[])}
function tests(){return read('vertex_tests',[])}
function slots(){return read('vertex_slots',[])}

function render(){
  document.body.className=state.dark?'dark-mode':'';
  const app=$('app');
  if(!loggedIn()){app.innerHTML=loginView();bindLogin();return;}
  app.innerHTML=portalView();bindPortal();
  if(state.page==='analytics') drawChart();
}
function loginView(){return `<div class="login-wrap"><section class="login-card">
  <img class="crest" src="icons/icon-192.png" alt="Vertex Science Academy crest"/>
  <h1 class="text-center" style="margin:0;font-size:25px">Vertex Science Academy</h1><p class="text-center text-muted" style="margin:6px 0 22px">Ambajogai • Class 10 CBSE Science</p>
  <form id="loginForm">
    <div class="form-group"><label class="label">Student Full Name</label><input id="name" class="input" required autocomplete="name" placeholder="Enter your full name as registered with the academy" /></div>
    <div class="form-group"><label class="label">Academy Access Key</label><div style="position:relative"><input id="pass" class="input" required type="${state.showPass?'text':'password'}" placeholder="Enter the verified academy passcode" style="padding-right:50px"/><button type="button" id="togglePass" style="position:absolute;right:5px;top:5px;border:0;background:transparent;padding:10px;color:#64748b">${icon(state.showPass?'eyeOff':'eye')}</button></div></div>
    ${state.enrollment?`<div class="form-group"><label class="label">Roll Number</label><input id="roll" class="input" required placeholder="Enter your academy roll number" /></div>`:''}
    ${state.error?`<div class="error">${escapeHtml(state.error)}</div>`:''}
    <button class="btn btn-primary w-full mt-3" type="submit">${state.enrollment?'Complete Enrollment & Enter':'Verify & Enter Portal'}</button>
  </form>
  <p class="text-center text-sm text-muted" style="margin:14px 0 4px">Don't have your access key? Contact Academy Office, Ambajogai.</p>
  <p class="text-center text-xs text-orange">${icon('lock',13)} Owner-controlled access • No email required</p>
</section></div>`}
async function handleLogin(e){
  e.preventDefault();state.error='';const name=$('name').value.trim(),pass=$('pass').value;const hash=await sha256(pass);
  if(name.length<2){state.error='Enter your full name.';render();return}
  if(hash!==OWNER_KEY_SHA256){state.error='The academy access key is not verified.';render();return}
  const p=profile();
  if(!p){if(!state.enrollment){state.enrollment=true;render();return}const roll=$('roll').value.trim();if(!roll){state.error='Enter your roll number to complete enrollment.';render();return}setProfile({fullName:name,rollNumber:roll,board:'Class 10 CBSE Board',branch:'Ambajogai',targetPercentage:95,loggedIn:true});state.enrollment=false;state.page='home';render();return}
  if(p.fullName.toLowerCase()!==name.toLowerCase()){state.error='Name does not match the enrolled profile.';render();return}
  p.loggedIn=true;setProfile(p);state.page='home';render();
}
function bindLogin(){$('loginForm').addEventListener('submit',handleLogin);$('togglePass').addEventListener('click',()=>{state.showPass=!state.showPass;render()})}

function portalView(){const p=profile();return `<div class="app-shell"><header class="topbar"><div class="brand"><img src="icons/icon-192.png" alt=""/><div><div class="brand-title">Vertex Science Academy</div><div class="brand-sub">Ambajogai • CBSE Class 10 Science</div></div></div></header><main class="main">${pageView(p)}</main><nav class="nav">${[['home','Home','home'],['syllabus','Syllabus','book'],['analytics','Analytics','chart'],['slots','Slots','calendar'],['profile','Profile','user']].map(([id,t,i])=>`<button class="${state.page===id?'active':''}" data-page="${id}">${icon(i,20)}<span>${t}</span></button>`).join('')}</nav></div>`}
function pageView(p){if(state.page==='home')return homeView(p);if(state.page==='syllabus')return syllabusView();if(state.page==='analytics')return analyticsView();if(state.page==='slots')return slotsView();return profileView(p)}
function homeView(p){const c=chapters(),m=c.filter(x=>x.status==='Mastered').length,progress=c.length?m/c.length:0,t=tests();return `<div><div class="flex justify-between items-center mb-4"><div><h2 style="margin:0">Good to see you, ${escapeHtml(firstName(p.fullName))}</h2><p class="text-muted" style="margin:5px 0">Your Class 10 Science command center</p></div><span class="rounded-full" style="background:#fff7ed;color:var(--saffron);padding:8px 10px;font-weight:800">${p.targetPercentage}% target</span></div>
<section class="card hero"><div class="flex items-center gap-4"><div class="ring" style="--progress:${progress}"><div class="ring-fill"></div><span>${Math.round(progress*100)}%</span></div><div><div class="text-sm" style="opacity:.8">Academic Target</div><div style="font-size:28px;font-weight:800">${p.targetPercentage}%</div><div class="text-sm" style="opacity:.8">${m} of ${c.length} chapters mastered</div></div></div></section>
<section class="card mt-4"><h3 class="section-title">Syllabus Progress</h3><div class="progress"><span style="width:${progress*100}%"></span></div><div class="text-sm text-muted mt-2">${Math.round(progress*100)}% mastery complete</div></section>
<section class="card mt-4"><h3 class="section-title">Mock Test Snapshot</h3>${t.length?`<div class="metric-grid">${metric('Average',Math.round(t.reduce((a,x)=>a+x.score/x.maxScore*100,0)/t.length)+'%')}${metric('Tests',t.length)}${metric('Best',Math.max(...t.map(x=>x.score))+'/80')}</div>`:`<p class="text-muted">No completed mock tests yet. Your analytics will appear after your first test.</p>`}</section>
<section class="card mt-4"><h3 class="section-title">Today's Focus</h3><p class="text-muted" style="margin:0">Revise one weak chapter, complete PYQs, then log your study session.</p></section></div>`}
function metric(a,b){return `<div class="metric"><span class="text-xs text-muted">${a}</span><b>${b}</b></div>`}
function syllabusView(){const c=chapters().filter(x=>x.subject===state.subject);return `<div><h2 style="margin:0">Chapter Mastery</h2><p class="text-muted">Tap a chapter to cycle its mastery status.</p><div class="tabs">${['Physics','Chemistry','Biology'].map(s=>`<button class="tab ${state.subject===s?'active':''}" data-subject="${s}">${s}</button>`).join('')}</div><div style="margin-top:12px">${c.map(x=>`<section class="card mb-3" data-chapter="${x.id}"><div class="chapter"><div class="check ${x.status==='Mastered'?'mastered':''}">${x.status==='Mastered'?icon('check',16):''}</div><div style="flex:1"><div class="font-semibold">${escapeHtml(x.chapter)}</div><div class="status ${statusClass(x.status)}">${x.status}</div></div>${icon('chevron',18)}</div></section>`).join('')}</div></div>`}
function analyticsView(){const t=tests(),avg=t.length?Math.round(t.reduce((a,x)=>a+x.score/x.maxScore*100,0)/t.length):0,best=t.length?Math.max(...t.map(x=>x.score)):0;return `<div><h2 style="margin:0">Mock Test Analytics</h2><p class="text-muted">80-mark CBSE board pattern</p><div class="metric-grid mb-4">${metric('Average',avg+'%')}${metric('Tests',t.length)}${metric('Best',best+'/80')}</div><section class="card"><div class="flex justify-between items-center"><h3 class="section-title" style="margin:0">Score Trajectory</h3><button id="addTest" class="btn btn-accent">Add Result</button></div>${t.length?'<canvas id="chart" class="chart"></canvas>':'<p class="text-muted">Complete mock tests to unlock your score trajectory.</p>'}</section><section class="card mt-4"><h3 class="section-title">Strength / Weakness</h3><p class="text-muted" style="margin:0">${t.length?'Use your lowest-scoring subject and improvement notes as the next revision priority.':'Not enough test data yet.'}</p></section></div>`}
function slotsView(){return `<div><h2 style="margin:0">Exam Slot Booking</h2><p class="text-muted">Ambajogai academy center • 1-tap reservation</p><div class="slot-grid">${slots().map(s=>`<section class="card slot"><div class="date">${escapeHtml(s.date)}</div><div class="text-sm text-muted mt-2">${escapeHtml(s.time)} • ${escapeHtml(s.batch)}</div>${s.status==='Confirmed'?`<div class="seat mt-2">Seat ${escapeHtml(s.seat)}</div><button class="btn btn-muted w-full mt-3" disabled>Confirmed</button>`:`<button class="btn btn-primary w-full mt-3" data-book="${s.id}">Reserve</button>`}</section>`).join('')}</div></div>`}
function reportText(p){const c=chapters(),m=c.filter(x=>x.status==='Mastered').length;return `VERTEX SCIENCE ACADEMY — AMBAJOGAI\nParent Progress Report\n\nStudent: ${p.fullName}\nRoll No: ${p.rollNumber}\nClass: ${p.board}\nTarget: ${p.targetPercentage}%\n\nScience syllabus mastery: ${m}/${c.length} (${Math.round(m/c.length*100)}%)\n\nPhysics: ${c.filter(x=>x.subject==='Physics').map(x=>x.chapter+': '+x.status).join('; ')}\nChemistry: ${c.filter(x=>x.subject==='Chemistry').map(x=>x.chapter+': '+x.status).join('; ')}\nBiology: ${c.filter(x=>x.subject==='Biology').map(x=>x.chapter+': '+x.status).join('; ')}\n`}
function profileView(p){return `<div><h2 style="margin:0">Profile & Settings</h2><p class="text-muted">Your academy portal preferences</p><section class="card mb-3"><h3 class="section-title">Student Details</h3><div class="font-bold">${escapeHtml(p.fullName)}</div><div class="text-muted">Roll No: ${escapeHtml(p.rollNumber)}</div><div class="text-muted">${p.board} • ${p.branch}</div></section><section class="card mb-3"><h3 class="section-title">Academic Target</h3><input id="target" class="input" type="number" min="1" max="100" value="${p.targetPercentage}"/><button id="saveTarget" class="btn btn-primary mt-3">Save Target</button></section><section class="card mb-3"><div class="flex items-center justify-between"><div><h3 class="section-title" style="margin:0">Appearance</h3><span class="text-muted text-sm">Dark mode</span></div><button id="darkToggle" class="switch ${state.dark?'on':''}" aria-label="Toggle dark mode"><i></i></button></div></section><section class="card mb-3"><h3 class="section-title">Parent Progress Report</h3><button id="reportBtn" class="btn btn-primary w-full">${icon('print')} Preview / Export Report</button></section><section class="card mb-3"><h3 class="section-title">Data Backup</h3><div class="flex gap-2"><button id="exportBtn" class="btn btn-muted" style="flex:1">${icon('download')} Export</button><label class="btn btn-muted" style="flex:1">${icon('upload')} Import<input id="importFile" type="file" accept="application/json" class="hidden"/></label></div></section><button id="logout" class="btn btn-danger w-full">${icon('logout')} Sign out</button></div>`}
function bindPortal(){document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{state.page=b.dataset.page;render()});document.querySelectorAll('[data-subject]').forEach(b=>b.onclick=()=>{state.subject=b.dataset.subject;render()});document.querySelectorAll('[data-chapter]').forEach(el=>el.onclick=()=>{const id=el.dataset.chapter,c=chapters(),x=c.find(v=>v.id===id);x.status=nextStatus(x.status);write('vertex_chapters',c);logActivity('Revision',`Updated ${x.chapter} → ${x.status}`);render()});document.querySelectorAll('[data-book]').forEach(b=>b.onclick=()=>{const id=Number(b.dataset.book),s=slots(),x=s.find(v=>v.id===id);x.status='Confirmed';x.seat='VS-'+(100+x.id);write('vertex_slots',s);logActivity('Booking',`Booked ${x.date} ${x.time}`);render()});const save=$('saveTarget');if(save)save.onclick=()=>{const p=profile();p.targetPercentage=Math.min(100,Math.max(1,Number($('target').value)||p.targetPercentage));setProfile(p);render()};const dt=$('darkToggle');if(dt)dt.onclick=()=>{state.dark=!state.dark;localStorage.setItem('vertex_dark',state.dark?'1':'0');render()};const out=$('logout');if(out)out.onclick=()=>{const p=profile();p.loggedIn=false;setProfile(p);state.page='home';render()};const rb=$('reportBtn');if(rb)rb.onclick=()=>{state.report=true;render()};const ex=$('exportBtn');if(ex)ex.onclick=exportData;const imp=$('importFile');if(imp)imp.onchange=e=>importData(e.target.files[0]);const add=$('addTest');if(add)add.onclick=()=>addMockTest();if(state.report)modalReport()}
function modalReport(){const p=profile();const wrap=document.createElement('div');wrap.className='modal-backdrop';wrap.innerHTML=`<div class="modal"><div class="flex justify-between items-center"><h3 style="margin:0">Parent Progress Report</h3><button id="closeReport" class="btn btn-muted">Close</button></div><pre class="report mt-4">${escapeHtml(reportText(p))}</pre><div class="flex gap-2 mt-3"><button id="shareReport" class="btn btn-primary" style="flex:1">Share</button><button id="printReport" class="btn btn-accent" style="flex:1">Print</button></div></div>`;document.body.appendChild(wrap);$('closeReport').onclick=()=>{state.report=false;wrap.remove()};$('shareReport').onclick=()=>{if(navigator.share)navigator.share({title:'Vertex Science Academy Progress Report',text:reportText(p)});else navigator.clipboard?.writeText(reportText(p))};$('printReport').onclick=()=>{const w=window.open('','_blank');if(w){w.document.write('<pre style="font:16px system-ui;white-space:pre-wrap">'+escapeHtml(reportText(p))+'</pre>');w.print()}}}

function addMockTest(){
  const testName=prompt('Test name (e.g. Science Mock 1)'); if(!testName)return;
  const subject=prompt('Subject (Physics / Chemistry / Biology / Full Science)','Full Science')||'Full Science';
  const score=Number(prompt('Score out of 80','')); if(!Number.isFinite(score)||score<0||score>80){alert('Enter a score from 0 to 80.');return}
  const rank=Number(prompt('Rank (optional)','0'))||0; const notes=prompt('Improvement notes (optional)','')||'';
  const t=tests();t.push({id:Date.now(),testName,subject,date:new Date().toISOString().slice(0,10),score,maxScore:80,rank,improvementNotes:notes});write('vertex_tests',t);logActivity('Quiz',`Recorded ${testName}`);render();
}
function exportData(){const data={profile:profile(),chapters:chapters(),tests:tests(),slots:slots(),activities:read('vertex_activities',[])};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='vertex-science-academy-backup.json';a.click();URL.revokeObjectURL(a.href)}
function importData(file){if(!file)return;const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(d.profile)setProfile(d.profile);if(d.chapters)write('vertex_chapters',d.chapters);if(d.tests)write('vertex_tests',d.tests);if(d.slots)write('vertex_slots',d.slots);if(d.activities)write('vertex_activities',d.activities);render()}catch{alert('Invalid Vertex Science Academy backup file.')}};r.readAsText(file)}
function drawChart(){const c=$('chart');if(!c)return;const t=tests();const dpr=devicePixelRatio||1,w=c.clientWidth,h=c.clientHeight;c.width=w*dpr;c.height=h*dpr;const ctx=c.getContext('2d');ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);ctx.strokeStyle='#1e3a8a';ctx.lineWidth=4;ctx.lineCap='round';const pts=t.map((x,i)=>({x:t.length===1?w/2:20+i*(w-40)/(t.length-1),y:h-18-(x.score/80)*(h-36)}));ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();ctx.fillStyle='#f97316';pts.forEach(p=>{ctx.beginPath();ctx.arc(p.x,p.y,6,0,Math.PI*2);ctx.fill()})}
seed();
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
window.addEventListener('resize',()=>state.page==='analytics'&&drawChart());
render();
